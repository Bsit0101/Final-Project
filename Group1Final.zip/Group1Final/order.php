<?php
session_start();
if (!isset($_SESSION['adminuser']))
{
   echo "<script>alert('Login First!'); location.href='login.php';</script>";
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="javascript" href="bootstrap/js/bootstrap.min.js">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.0/css/all.css">
 	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.0/css/v4-shims.css">
 	<link rel="stylesheet" type="text/css" href="css/orderstyle.css">
 	<link rel="stylesheet" type="text/css" href="datatables/datatables.min.css"/>
</head>
<body>
<!--NAVBAR-->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">MOMMYS TUMMY</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto w-100 justify-content-end sticky-top">
      <li class="nav-item">
        <a class="nav-link" href="menu.php" >Menu</a>
      </li>
      <li class="nav-item">
      	<a class="nav-link active" href="order.php">Orders</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="account.php">Accounts</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="logout.php">Logout</a>
      </li>
  </div>
</nav>
<!--BANNER-->
<div class="banner1">
	<img src="images/orderbanner.png">
</div>
<h3 class="display-2" style="text-align: center;">People Who Ordered</h3>

<!--ORDER LIST-->
<div class="container">
	<table class="table table-striped" id="ordertable">
		<thead>
		   	<tr>
		   		<th scope="col"></th>
			    <th>Full Name</th>
			    <th>Location</th>
			    <th>Contact Number</th>
			    <th>Date Ordered</th>
			    <th></th>
		   	</tr>
		</thead>
		<tbody>
		   	<tr>
			    <th scope="row"></th>
			    <td>Ahr</td>
			    <td>Mangaldan</td>
			    <td>0912-345-6789</td>
			    <td>10/02/2019</td>
			    <td>
			    	<button type="button" class="btn btn-success viewbtn" data-toggle="modal"  data-target="">VIEW</button>
			    	<button type="button" class="btn btn-danger deletebtn" data-toggle="modal"  data-target="">DELETE</button>
			    </td>
		   	</tr>
		   	<tr>
			    <th scope="row"></th>
			    <td>Jay</td>
			    <td>Dagupan</td>
			    <td>0987-654-3210</td>
			    <td>12/29/2039</td>
			    <td>
			    	<button type="button" class="btn btn-success viewbtn" data-toggle="modal"  data-target="">VIEW</button>
			    	<button type="button" class="btn btn-danger deletebtn" data-toggle="modal"  data-target="">DELETE</button>
			    </td>
		   	</tr>
		   	<tr>
			    <th scope="row"></th>
			    <td>Aaronr</td>
			    <td>Lingayen</td>
			    <td>0976-854-3216</td>
			    <td>01/15/2029</td>
			    <td>
			    	<button type="button" class="btn btn-success viewbtn" data-toggle="modal"  data-target="">VIEW</button>
			    	<button type="button" class="btn btn-danger deletebtn" data-toggle="modal"  data-target="">DELETE</button>
			    </td>
		   	</tr>
		</tbody>
	</table>
</div>
<!--VIEW MODAL-->
<div class="modal fade" id="vieworder" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  	<div class="modal-dialog" role="document">
	    <div class="modal-content">
	    	<div class="modal-header">
		        <h5 class="modal-title" id="exampleModalLongTitle">Edit Menu Information</h5>
		        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
		          <span aria-hidden="true">&times;</span>
		        </button>
	   		</div>
	    	<div class="modal-body">
	        <form action="menu.php" method="POST" enctype="multipart/form-data">
	        	<div class="form-group">
	        		<input type="hidden" name="updateid" id="updateid">
					<label for="#menuimage">Menu Image</label>
					<input type="file" class="form-control-file" id="menuimage" name="menuimage" required>
				</div>
				<div class="form-group">
					<label for="#menuname">Menu Name</label>
					<input type="text" class="form-control" id="menuname" name="menuname" required>
				</div>
				<div class="form-group">
					<label for="#menusize">Menu Sizes</label>
					<input type="text" class="form-control" id="menusize" name="menusize" required>
				</div>
				<div class="form-group">
					<label for="#menuprice">Menu Prices</label>
					<input type="number" class="form-control" id="menuprice" name="menuprice" required>
				</div>
		    	<div class="modal-footer">
			    	<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
			    	<input type="submit" value="Update Menu" name="updatemenu" class="btn btn-primary">
		    	</div>
		    </form>
		    </div>
	    </div>
  	</div>
</div>

<!--DELETE MODAL-->
<div class="modal fade" id="deleteorder" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  	<div class="modal-dialog" role="document">
	    <div class="modal-content">
	    	<div class="modal-header">
		        <h5 class="modal-title" id="exampleModalLongTitle">Delete Menu</h5>
		        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
		          <span aria-hidden="true">&times;</span>
		        </button>
	   		</div>
	    	<div class="modal-body">
	        <form action="menu.php" method="POST" enctype="multipart/form-data">
	        	<div class="form-group">
	        		<input type="hidden" name="deleteid" id="deleteid">
				</div>
				<h4>Do You Want To Delete This Menu?</h4>
		    	<div class="modal-footer">
			    	<button type="button" class="btn btn-secondary" data-dismiss="modal">NO</button>
			    	<input type="submit" value="Delete Menu" name="deletemenu" class="btn btn-primary">
		    	</div>
		    </form>
		    </div>
	    </div>
  	</div>
</div>
<!--CONTACTS-->
<div id="contacts">
	<div class="container-fluid padding">
		<div class="row text-center padding">
			<div class="col-12">
				<h2>Contacts</h2>
			</div>
			<hr>
			<div class="col-12 social padding">
				<a href="https://www.facebook.com/"><i class="fab fa-facebook"></i></a>
				<a href="https://www.twitter.com/"><i class="fab fa-twitter"></i></a>
				<a href="https://www.instagram.com/"><i class="fab fa-instagram"></i></a>
			</div>
		</div>
	</div>
</div>
<!--FOOTER-->
<footer>
	<div class="container-fluid padding">
		<div class="row text-center">
			<div class="col-md-4">
				<hr class="light">
				<h5>Contacts</h5>
				<hr class="light">
				<p>(+63)927-016-1988</p>
				<p>abcdefhijk@gmail.com</p>
			</div>
			<div class="col-md-4">
				<hr class="light">
				<h5>Operating Hours</h5>
				<hr class="light">
				<p>MON - FRI : 8:00 AM-5:00 PM</p>
				<p>SAT - SUN : 9:00 AM-4:00 PM</p>
			</div>
			<div class="col-md-4">
				<hr class="light">
				<h5>Home Area</h5>
				<hr class="light">
				<p>Anolid Highway</p>
				<p>Mangaldan Pangasinan</p>
			</div>
			<div class="col-12">
				<hr class="light-100">
				<h5>&copy;mommystummy.com</h5>
			</div>
		</div>
	</div>
</footer>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
<script type="text/javascript" src="datatables/datatables.min.js"></script>

<script type="text/javascript">
	$(document).ready(function() {
    	$('#ordertable').DataTable();
	} );
</script>

<script type="text/javascript">
	$(document).ready(function(){
		$('.viewbtn').on('click', function(){

			$('#viewmenu').modal('show');

				$tr = $(this).closest('tr');

				var data = $tr.children("td").map(function(){
					return $(this).text();
				}).get();

				console.log(data);

				$('#updateid').val(data[0]);
				$('#menuimage').val(data[1]);
				$('#menuname').val(data[2]);
				$('#menusize').val(data[3]);
				$('#menuprice').val(data[4]);

		});
	});
</script>

<script type="text/javascript">
	$(document).ready(function(){
		$('.deletebtn').on('click', function(){

			$('#deleteorder').modal('show');

				$tr = $(this).closest('tr');

				var data = $tr.children("td").map(function(){
					return $(this).text();
				}).get();

				console.log(data);

				$('#deleteid').val(data[0]);

		});
	});
</script>
</body>
</html>