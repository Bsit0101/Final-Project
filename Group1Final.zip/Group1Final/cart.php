<?php
session_start();
$connect=mysqli_connect("localhost","root","","onlineordering");

if(isset($_POST["add_to_cart"]))  
 {  
      if(isset($_SESSION["shopping_cart"]))  
      {  
           $item_array_id = array_column($_SESSION["shopping_cart"], "item_id");  
           if(!in_array($_GET["id"], $item_array_id))  
           {  
                $count = count($_SESSION["shopping_cart"]);  
                $item_array = array(  
                     'item_id'               =>     $_GET["id"],  
                     'item_name'               =>     $_POST["hidden_name"],  
                     'item_price'          =>     $_POST["hidden_price"],  
                     'item_quantity'          =>     $_POST["quantity"]  
                );  
                $_SESSION["shopping_cart"][$count] = $item_array;  
                
           }  
           else  
           {  
                echo '<script>alert("Item Already Added")</script>';  
                echo '<script>window.location="index.php"</script>';  
           }  
      }  
      else  
      {  
           $item_array = array(  
                'item_id'               =>     $_GET["id"],  
                'item_name'               =>     $_POST["hidden_name"],  
                'item_price'          =>     $_POST["hidden_price"],  
                'item_quantity'          =>     $_POST["quantity"]  
           );  
           $_SESSION["shopping_cart"][0] = $item_array;  
      }  
 }  
 if(isset($_GET["action"]))  
 {  
      if($_GET["action"] == "delete")  
      {  
           foreach($_SESSION["shopping_cart"] as $keys => $values)  
           {  
                if($values["item_id"] == $_GET["id"])  
                {  
                     unset($_SESSION["shopping_cart"][$keys]);  
                     echo '<script>alert("Item Removed")</script>';  
                     echo '<script>window.location="index.php"</script>';  
                }  
           }  
      }  
 }  
 ?>  


<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="javascript" href="bootstrap/js/bootstrap.min.js">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.0/css/all.css">
 	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.0/css/v4-shims.css">
 	<link rel="stylesheet" type="text/css" href="css/menustyle.css">
 	<link rel="stylesheet" type="text/css" href="datatables/datatables.min.css"/>
</head>
<body>
<!--NAVBAR-->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">MOMMYS TUMMY</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto w-100 justify-content-end sticky-top">
      <li class="nav-item">
        <a class="nav-link " href="index.php">Menu</a>
      </li>
      <li class="nav-item">
      	<a class="nav-link active" href="cart.php">Cart</a>
      </li>
     
      <li class="nav-item">
        <a class="nav-link" href="#">About us</a>
      </li>
  </div>
</nav>
<!--BANNER-->
<div class="banner1">
	<img src="images/orderbanner.png">
</div>
<br>
<br>
<!--ADDING MENU-->
<h3 class="display-2" style="text-align: center;">Your Orders</h3>
<div class="container pads" style="margin-top: 20px;margin-bottom: 20px;">
	<div class="row">
		<div class="col-sm-8">
			<input type="hidden">
		</div>
		<div class="col-sm-2">
			<input type="hidden">
		</div>
		
         
    
		
		
		
		<div style="clear:both"></div>  
                <br />  
                <h3>Order Details</h3>  
                <div class="table-responsive">  
                     <table class="table table-bordered">  
                          <tr>  
                               <th width="40%">Item Name</th>  
                               <th width="10%">Quantity</th>  
                               <th width="20%">Price</th>  
                               <th width="15%">Total</th>  
                               <th width="15%">Action</th>  
                          </tr>  
                          <?php   
                          if(!empty($_SESSION["shopping_cart"]))  
                          {  
                               $total = 0;  
                               foreach($_SESSION["shopping_cart"] as $keys => $values)  
                               {  
                          ?>  
                          <tr>  
                               <td><?php echo $values["item_name"]; ?></td>  
                               <td><?php echo $values["item_quantity"]; ?></td>  
                               <td>P <?php echo $values["item_price"]; ?></td>  
                               <td>P <?php echo number_format($values["item_quantity"] * $values["item_price"], 2); ?></td>  
                               <td><a href="index.php?action=delete&id=<?php echo $values["item_id"]; ?>"><span class="text-danger">Remove</span></a> &nbsp;&nbsp;&nbsp;</td>
                          </tr>  
                          <?php  
                                    $total = $total + ($values["item_quantity"] * $values["item_price"]);  
                               }  
                          ?>  
                          <tr>  
                               <td colspan="3" align="right">Total</td>  
                               <td align="right">P <?php echo number_format($total, 2); ?></td>  
                               <td>

                                <a href="session.php"><button class="btn btn-warning form-control" type="button" >CANCEL</button></a><br><br>



                               <button class="btn btn-danger form-control" data-toggle="modal" data-target="#addmenu">Order Now</button>



                             

                          </tr>  




                          
                          <?php  
                          }  
                          ?>  
                     </table>  
                </div>  
           </div>  
           <br />  


		

</body>
</html>







<!--ADDING MENU-->


     
  
<!--Add Modal-->
<div class="modal fade" id="addmenu" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">Customer Information</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
          <form action="menu.php" method="POST" enctype="multipart/form-data">
            <div class="form-group">
           <div class="form-group">
          <label for="#menuname">Full Name</label>
          <input type="text" class="form-control"  name="#" required>
        </div>
         <div class="form-group">
          <label for="#menuname">Location</label>
          <input type="text" class="form-control"  name="#" required>
        </div>
         <div class="form-group">
          <label for="#menuname">Contact Number</label>
          <input type="text" class="form-control"  name="#" required>
        </div>
         <div class="form-group">
          <label for="#menuname">Date Ordered</label>
          <input type="text" class="form-control"  name="#" required>
        </div>
         <!--  <label for="#menuimage" >Menu Image</label>
          <input type="file" class="form-control-file" name="menuimage" required>
        </div>
        <div class="form-group">
          <label for="#menuname">Menu Name</label>
          <input type="text" class="form-control"  name="menuname" required>
        </div>
        <div class="form-group">
          <label for="#menucategory">Menu Category</label>
          <select name="menucategory" id="menucategory" class="form-control" required>
            <option selected="true" disabled>Choose Category</option>
            <option>Vegetables</option>
            <option>Pork</option>
            <option>Chicken</option>
            <option>Beef</option>
            <option>Seafood</option>
            <option>All Day Breakfast</option>
            <option>Rice Meals</option>
            <option>All Day Mereinda</option>
            <option>Pasta</option>
            <option>Beverages</option>
          </select>
        </div>
        <div class="form-group">
          <label for="#menuprice">Menu Prices</label>
          <input type="number" class="form-control" name="menuprice" required>
        </div> -->
          <div class="modal-footer">
            <button type="button" class="btn btn-warning" data-dismiss="modal">Close</button>
            
            <!-- <input type="submit" value="Check Out" name="addmenu" class="btn btn-danger"> -->
            <a href="session.php">
            <button class="btn btn-danger form-control" type="button" >Check out</button></a><br><br>
          </div>
        </form>
        </div>
      </div>
    </div>
</div>


       
  






<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
<script type="text/javascript" src="datatables/datatables.min.js"></script>


</body>
</html>