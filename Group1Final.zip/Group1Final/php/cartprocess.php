<?php

$mysqli = new mysqli('localhost','root','','onlineordering') or die(mysqli_error($mysqli));

if (isset($_POST['addmenu']))
{
	$menuimage=$_FILES['menuimage']['name'];
	$menuname=$_POST['menuname'];
	$menucategory=$_POST['menucategory'];
	$menuprice=$_POST['menuprice'];
	$target="images/".basename($_FILES['menuimage']['name']);

	$mysqli->query("INSERT INTO menutable(menuimage,menuname,menucategory,menuprice) VALUES('$menuimage','$menuname','$menucategory','$menuprice')") or die($mysqli->error);

	if (move_uploaded_file($_FILES['']['name'], $target)) {
			echo "";
		}

	header("location: menu.php");

}
if (isset($_POST['updatemenu']))
{
	$id=$_POST['updateid'];
	$menuimage=$_FILES['menuimage']['name'];
	$menuname=$_POST['menuname'];
	$menucategory=$_POST['menucategory'];
	$menuprice=$_POST['menuprice'];
	$target="images/".basename($_FILES['menuimage']['name']);

	$mysqli->query("UPDATE menutable SET menuimage='$menuimage', menuname='$menuname',menucategory='$menucategory',menuprice='$menuprice' WHERE id=$id") or die($mysqli->error);

}

if (isset($_POST['deletemenu']))
{
	$deleteid=$_POST['deleteid'];
	$mysqli->query("DELETE FROM menutable WHERE id=$deleteid") or die($mysqli->error());

}

?>