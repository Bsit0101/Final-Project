<?php

session_start();

$mysqli = new mysqli('localhost','root','','onlineordering') or die(mysqli_error($mysqli));

	if(isset($_POST['login']))
	{
		$adminuser =$_POST['adminuser'];
		$adminpass =$_POST['adminpass'];

		if (empty($adminuser) || empty($adminpass))
		{
			echo '<script type="text/javascript">alert("Please Fill Up Before Logging In");</script>';
		}
		else
		{
			$query="SELECT * FROM admin WHERE adminuser='".$adminuser."' and adminpass='".$adminpass."'";
			$result = mysqli_query($mysqli,$query);
			if(mysqli_fetch_assoc($result))
			{
				$_SESSION['adminuser'] 	= $_POST['adminuser'];
				$_SESSION['adminpass'] 	= $_POST['adminpass'];
				$_SESSION['firstname'] 	= $_POST['firstname'];
				$_SESSION['lastname'] 	= $_POST['lastname'];
				$_SESSION['role']		= $_POST['role'];
				header("location:menu.php");
			}
			else
			{
				echo '<script type="text/javascript">alert("Incorrect UserName and Password");</script>';
			}
		}
	}

?>